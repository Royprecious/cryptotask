
async function fetchCandlestickData(chart, symbol, interval = '1m') {
    try {
        const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}`);
        const data = await response.json();

        const formattedData = data.map(item => {
            const open = parseFloat(item[1]);
            const close = parseFloat(item[4]);

            return {
                x: item[0], 
                o: open,     
                h: parseFloat(item[2]), 
                l: parseFloat(item[3]), 
                c: close,    
             
                borderColor: close > open ? 'rgb(73, 212, 73)' : 'rgba(255, 0, 0, 0.6)',
                backgroundColor: close > open ? 'rgb(73, 212, 73)' : 'rgba(255, 0, 0, 0.3)' 
            };
        });


        chart.data.datasets[0].data = formattedData;


        chart.update();
    } catch (error) {
        console.error("Error fetching candlestick data:", error);
    }
}

function initializeChart() {
    const ctx = document.getElementById('candlestickChart').getContext('2d');

    const chart = new Chart(ctx, {
        type: 'candlestick',
        data: {
            datasets: [{
                label: 'ETHBTC Candlestick',
                data: [],
                borderWidth: 1
            }]
        },
        options: {
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'minute',
                        tooltipFormat: 'MM/dd/yyyy HH:mm'
                    },
                    title: {
                        display: true,
                        text: 'Time'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Price'
                    },
                    beginAtZero: false
                }
            }
        }
    });

    return chart;
}

function startRealTimeCandlestickUpdates(symbol, interval) {
    const chart = initializeChart();


    fetchCandlestickData(chart, symbol, interval);
    setInterval(() => {
        fetchCandlestickData(chart, symbol, interval);
    }, 60000);
}


startRealTimeCandlestickUpdates('ETHBTC', '1m');
